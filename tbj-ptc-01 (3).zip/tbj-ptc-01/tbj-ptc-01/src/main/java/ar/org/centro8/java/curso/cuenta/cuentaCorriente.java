package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class CuentaCorriente extends Cuenta {
    private double montoAutorizado;


    public CuentaCorriente(int numeroCuenta, Cliente clienteAsociado, double saldo, double montoAutorizado) {
        super(numeroCuenta, clienteAsociado, saldo);
        this.montoAutorizado = montoAutorizado;
    }
    public double getMontoAutorizado(){
        return montoAutorizado;
    }
    public void setMontoAutorizado(double montoAutorizado){
        this.montoAutorizado = montoAutorizado;
    }

public boolean extraerEfectivo(double monto) {
    if(monto <=0) return false;
    //permite quedar en descubierto hasta montoAutorizado
    if (getSaldo() + montoAutorizado >= monto){
    setSaldo(getSaldo() - monto);
    return true;
    
}
return false;

}

public abstract void despositarEfectivo(int i);
}
