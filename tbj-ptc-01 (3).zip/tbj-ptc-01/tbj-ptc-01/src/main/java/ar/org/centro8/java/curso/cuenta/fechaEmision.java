package ar.org.centro8.java.curso.cuenta;

/**
 * fechaEmision
 */
public record fechaEmision() {

}
