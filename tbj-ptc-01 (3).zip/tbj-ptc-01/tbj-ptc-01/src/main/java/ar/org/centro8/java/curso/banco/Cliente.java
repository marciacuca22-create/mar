package ar.org.centro8.java.curso.banco;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter
@ToString (callSuper = true)
@RequiredArgsConstructor
public abstract class Cliente{
    private  final int numeroCliente;

    
    
    }



    
