package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString (callSuper = true)
public class CuentaConvertibilidad extends CuentaCorriente {
    private double saldoDolares;
    private double cotizacion;

    public CuentaConvertibilidad(int numeroCuenta, Cliente clienteAsociado, double saldo, double montoAutorizado,
        double saldoDolares,double cotizacion) {
        super(numeroCuenta, clienteAsociado, saldo, montoAutorizado);
        this.saldoDolares = saldoDolares;
        this.cotizacion = cotizacion;
    }

    public void depositarDolares(double monto) {
        if(monto >0) this.saldoDolares += monto;
    }

    public boolean extraerDolares(double monto) {
        if(monto >0 && saldoDolares>= monto){
        saldoDolares -= monto;
        return true;
    }
    return false;
}
    public void convertirPesosADolares(double montoPesos) {
        if(montoPesos >0 && getSaldo() + getMontoAutorizado()>= montoPesos){
        setSaldo(getSaldo() - montoPesos);
        saldoDolares += montoPesos / cotizacion;
    }
}
    public void convertirDolaresAPesos(double montoDolares) {
        if(montoDolares >0 && saldoDolares >= montoDolares){
        saldoDolares -= montoDolares;
        setSaldo(getSaldo() + montoDolares * cotizacion);
    
    }
}

    @Override
    public void despositarEfectivo(int i){
        System.out.println("el monto es:"+"pesos"+2000);
    }

}

    
    
