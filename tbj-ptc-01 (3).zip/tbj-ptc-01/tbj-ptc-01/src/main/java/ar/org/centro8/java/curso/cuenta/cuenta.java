package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public abstract class Cuenta {
    private final int numeroCuenta;
    private final Cliente clienteAsociado;
    private double saldo;

    
    public Cuenta(int numeroCuenta, Cliente clienteAsociado, double saldo) {
        this.numeroCuenta = numeroCuenta;
        this.clienteAsociado = clienteAsociado;
        this.saldo = saldo;
    }

    public abstract boolean extraerEfectivo(double monto);
}
