package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;
import ar.org.centro8.java.curso.banco.ClienteIndividual;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString (callSuper = true)//hace que tambien infruya los atributos que hereda de la clase padre
// en forma de cadena de texto
public class CajaDeAhorro extends Cuenta {
    private double tasaInteres;
    
    //contructor el es metodo que se ejecuta cuando crea  un objeto de la clase
    public CajaDeAhorro(int numeroCuenta, Cliente clienteAsociado, int i) {
        super(numeroCuenta, clienteAsociado);
        this.tasaInteres = tasaInteres;
    }

    @Override//indica que esta implementado un metodo heredado de la clase padre
    public boolean extraerEfectivo(double monto) {
        if (monto >0 && monto <= getSaldo()) {
        setSaldo(getSaldo()- monto);
        System.out.println("se retiro:$"+monto+ "con exito, le quedan $" + getSaldo());
        return true;
    }
    System.out.println("fondo insuficiente");
    return false;
    }
    // metodo que permite retirar dinero si el monto es válido
    // y hay saldo suficiente para extraer, devuelve true si se realiza
    // la extracción o false si no se puede realizar.
    public double calcularTasaInteres() {
        double interes = getSaldo() * tasaInteres / 100;
        setSaldo(getSaldo()+ interes);
        System.out.println("interes acreditado:"+ interes);
        System.out.println("Su saldo es:$"+ getSaldo());
        return interes;
    }

}




