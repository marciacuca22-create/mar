package ar.org.centro8.java.curso;

import java.time.LocalDate;

import ar.org.centro8.java.curso.banco.Cliente;
import ar.org.centro8.java.curso.banco.ClienteEmpresa;
import ar.org.centro8.java.curso.banco.ClienteIndividual;
import ar.org.centro8.java.curso.cuenta.CajaDeAhorro;
import ar.org.centro8.java.curso.cuenta.Cheque;
import ar.org.centro8.java.curso.cuenta.CuentaConvertibilidad;
import ar.org.centro8.java.curso.cuenta.CuentaCorriente;

public class TestGeneral{
	public static void main(String[] args){

        System.out.println("\n===== Testeo =====");
        ClienteIndividual ind = new ClienteIndividual(10, "Brian", "Mamani", "45967810");
        ClienteEmpresa emp = new ClienteEmpresa(25, "Dotar Soller", "20-45879635-7");
        ClienteEmpresa emp2 = new ClienteEmpresa(46, "Tom", "45-15789634-5");
        
        CajaDeAhorro ahorro = new CajaDeAhorro(45, ind, 12);
        CuentaCorriente corrientes = new CuentaCorriente(42, emp, 20000);
        Cheque cheque2 = new Cheque(45200, "Banco Galicia", LocalDate.of(2026, 05, 16));

        CuentaCorriente corrientes2 = new CuentaCorriente(50, emp2, 20000);
        Cheque cheque3 = new Cheque(128000, "Banco Macro", LocalDate.of(2026, 5, 30));
        // LocalDate.of() sirve para crear una fecha especifica, en (año, mes, dia)

        CuentaConvertibilidad convertible = new CuentaConvertibilidad(55, emp2, 15000, 0, 0);
        /* CuentaConvertibilidad convertible2 = new CuentaConvertibilidad(74, ind, 23000); */
        
        System.out.println(ahorro);
        System.out.println(corrientes);
        System.out.println(corrientes2);
        System.out.println(convertible);
        
        System.out.println("\n===== Ahorro =====");
        System.out.println("La cuenta es: " + ahorro.getSaldo());
        ahorro.despositarEfectivo(142500);
        ahorro.extraerEfectivo(91000);
        System.out.println("La tasa es de: %" + ahorro.getTasaInteres());
        ahorro.calcularTasaInteres();

        System.out.println("\n===== Corriente con Cheque =====");
        System.out.println("===== Cliente 1 =====");
        System.out.println("La cuenta es: " + corrientes.getSaldo());
        corrientes.despositarEfectivo(546000);
        corrientes.extraerEfectivo(1500000);
        corrientes.extraerEfectivo(150000);
        System.out.println("Saldo: $" + corrientes.getSaldo());
        corrientes.despositarCheque(cheque2);
        System.out.println("Saldo: $" + corrientes.getSaldo());
        
        System.out.println("\n===== Cliente 2 =====");
        System.out.println("La cuenta es: " + corrientes2.getSaldo());
        corrientes2.despositarEfectivo(556200);
        corrientes2.extraerEfectivo(652500);
        corrientes2.extraerEfectivo(146200);
        System.out.println("Saldo: $" + corrientes2.getSaldo());
        corrientes2.despositarCheque(cheque3);
        System.out.println("Saldo: $" + corrientes2.getSaldo());

        System.out.println("\n===== Convertibilidad =====");
        System.out.println("===== Pesos =====");
        System.out.println("La cuenta es: " + corrientes2.getSaldo());
        System.out.println("Saldo Pesos: $" + convertible.getSaldo());
        convertible.despositarEfectivo(125000);
        convertible.extraerEfectivo(525000);
        convertible.extraerEfectivo(46500);
        System.out.println("Saldo Pesos: $" + convertible.getSaldo());
        
        System.out.println("\n===== Dolares =====");
        System.out.println("Saldo Dolares: $" + convertible.getSaldoDolares());
        convertible.depositarDolares(15000);
        convertible.extraerDolares(45000);
        convertible.extraerDolares(5000);
        System.out.println("Saldo Dolares: $" + convertible.getSaldoDolares());
        
        System.out.println("\n===== Convertir Pesos =====");
        System.out.println("Saldo Pesos: $" + convertible.getSaldo());
        convertible.convertirPesosADolares(10000, 5);
        System.out.println("Saldo total: U$D" + convertible.getSaldoDolares());
        System.out.println("Saldo Pesos: $" + convertible.getSaldo());
        
        System.out.println("\n===== Convertir Dolares =====");
        System.out.println("Saldo Dolares: $" + convertible.getSaldoDolares());
        convertible.convertirDolaresAPesos(6000, 4);
        System.out.println("Saldo total: $" + convertible.getSaldo());
        System.out.println("Saldo Dolares: $" + convertible.getSaldoDolares());
        
        System.out.println("\n===== Monto Total =====");
        System.out.println("Saldo en Pesos: $" + convertible.getSaldo());
        System.out.println("Saldo en Dolares: U$D" + convertible.getSaldoDolares());

        



    }
}

