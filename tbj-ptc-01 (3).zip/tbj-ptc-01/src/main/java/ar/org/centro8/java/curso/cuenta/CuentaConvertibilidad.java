package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;
import ar.org.centro8.java.curso.banco.ClienteEmpresa;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString (callSuper = true)
public class CuentaConvertibilidad extends CuentaCorriente {
    private double saldoDolares;
    

    public CuentaConvertibilidad(int numeroCuenta, Cliente clienteAsociado, int i, double saldoDolares, int j) {
        super(numeroCuenta, clienteAsociado, i);
        this.saldoDolares = saldoDolares;
    }

    public void depositarDolares(double monto) {
        if(monto >0) {
        saldoDolares += monto;
        System.out.println("Se deposito:U$D+ monto");
        }else{
            System.out.println("La cantidad depositada es incorrecta");
        }
    }

    public boolean extraerDolares(double monto) {
        if(monto >0 && monto <= saldoDolares){
        saldoDolares -= monto;
        System.out.println("Se retiro:U$D"+ monto);
        return true;
    }
    System.out.println("Fondo insufifientes");
    return false;
}
    public double convertirPesosADolares(double montoPesos, double tasa) {
        if(montoPesos <=0 || tasa <=  montoPesos + getSaldo()){
            System.out.println("El monto, la tasa o saldo es incorrecto");
            return 0;
        }
        double dolares = montoPesos / tasa;
        setSaldo(getSaldo() - montoPesos);
        saldoDolares += dolares;
        System.out.println("Dolares recibidos:U$D"+ dolares);
        return dolares;
    }

    public double convertirDolaresAPesos(double montoDolares, double tasa) {
        if(montoDolares <=0 || tasa <=0 || montoDolares > saldoDolares){
            System.out.println("El monto, la tasa o saldo son incorrecto");
            return 0;
        }
        double pesos = montoDolares * tasa;
        saldoDolares -= montoDolares;
        System.out.println("Pesos recibidos:$"+ pesos);
        return pesos;
    
    }
}


    
    
