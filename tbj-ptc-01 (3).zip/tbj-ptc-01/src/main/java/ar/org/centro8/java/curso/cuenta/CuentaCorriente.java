package ar.org.centro8.java.curso.cuenta;

import ar.org.centro8.java.curso.banco.Cliente;
import ar.org.centro8.java.curso.banco.ClienteEmpresa;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class CuentaCorriente extends Cuenta {
    private double montoAutorizado;


    public CuentaCorriente(int numeroCuenta, Cliente clienteAsociado, int i) {
        super(numeroCuenta, clienteAsociado);
        this.montoAutorizado = montoAutorizado;
    }
    
// metodo extraer efectivo si el monto es mayor que cero
// y no supera el saldo disponible más el monto autorizado
// devuelve true si la extracción se realiza o false si no se puede realizar
@Override
public boolean extraerEfectivo(double monto) {
    if(monto > 0 && monto <= getSaldo()+ montoAutorizado) {
    setSaldo(getSaldo() - monto);
    System.out.println("Se retira:$"+ monto);
    return true;
    
}
System.out.println("No se pudo realizar la extraccion");
return false;

}
// metodo depositar cheque el cheque tiene que existir y su monto debe ser mayor que cero.
// si el cheque es válido, suma su importe al saldo de la cuenta
// y muestra el monto depositado.
public void despositarCheque(Cheque cheque){
    if(cheque == null || cheque.getMonto() <= 0){
        System.out.println("Cheque o monto reducido");
    }else{
        setSaldo(getSaldo()+ cheque.getMonto());
        System.out.println("Cheque depositado:$"+ cheque.getMonto());
    }
    
}



}