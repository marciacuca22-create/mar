package ar.org.centro8.java.curso;

/**
 * CuentaConvertibilida
 */
public class CuentaConvertibilida {

}
